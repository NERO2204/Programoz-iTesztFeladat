<?php
       
function kiir()
{  
   
    

require_once './MySqlDB.php';

$ab = new MySqlDB();

$szemelyek = array();
$eredmeny= $ab->lekerdez("szemely", 1);

if ($eredmeny->num_rows > 0) 
{
    while($sor = $eredmeny->fetch_assoc()) 
    {   
        $szemelyek[] = $sor;
    
        
    }
     
    
   
}








//$txt="<select>"; 
//for ($index = 0; $index <count($szemelyek); $index++)
//{
//    $txt.="<option value='.$szemelyek[$index].'>.$szemelyek[$index].</option>";
//    
//}
//    
//}
//$txt.="</select>";
  //  return $txt;

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
}
    