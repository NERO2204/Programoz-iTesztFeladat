var autok=[];
var autokGyartoi=[];
var gyartoID;
var futasiAdatok=[];
var javitasiAdatok=[];


    
    
    
    
    
    
    




 
$(document).ready(function ()
{


 
$('#autoAdatokatBetolt').on('click',beolvas);
$('#autoFutasAdatokatMegjelenit').on('click',futasiAdatokatLeker);


   

  
});




//beolvasometodusok
function beolvas()
{
    console.log("ddd");
    $.ajax({
        type: "GET",
        url: "Model.php",
        success: function (result) {
            autok = JSON.parse(result);
            kiir();
        
        },
        error: function () {
            alert("Hiba az adatok beolvasásakor");
        }
    });
}

function futasiAdatokatLeker()
{
   
    $.ajax({
        type: "GET",
        url: "FutasiAdatokatLeker.php",
        success: function (result) {
            futasiAdatok = JSON.parse(result);
            futasiAdatokatkiir();
        
        },
        error: function () {
            alert("Hiba az adatok beolvasásakor");
        }
    });
    
}

function javitasiAdatokatLeker()
{
   
    $.ajax({
        type: "GET",
        url: "javitastLekerdez.php",
        success: function (result) {
            javitasiAdatok = JSON.parse(result);
            javitasiAdatokatkiir();
        
        },
        error: function () {
            alert("Hiba az adatok beolvasásakor");
        }
    });
    
}


//kiiro metodusok
function kiir()
{
   
    const jarmulista=document.getElementById('jarmulista');
    var txt="<div id='nagydoboz'>";
    txt+="<table>";
    txt+="<tr><th>Rendszam</th><th>Gyarto</th><th>Model</th>";
    for (var i = 0; i <autok.length; i++)
    {
        txt+="<tr>";
        txt+="<td>"+autok[i].Rendszam+"</td>";
        txt+="<td>"+autok[i].gyartoNeve+"</td>";
        txt+="<td>"+autok[i].nev+"</td>";
        txt+="</tr>";
        
    }
    txt+="</table>";
    txt+="</div>";
    
    
    
 jarmulista.innerHTML=txt;
    
}

function futasiAdatokatkiir()
{
     const jarmulista=document.getElementById('jarmulista');
     jarmulista.innerHTML="";
     
     
    var txt="<div id='nagydoboz'>";
    txt+="<table>";
    txt+="<tr><th>nev</th><th>Rendszam</th><th>megtettkilometer</th><th>kiviteliidopont</th><th>visszaviteliidopont</th></tr>";
    for (var i = 0; i <futasiAdatok.length; i++)
    {
        txt+="<tr>";
        txt+="<td>"+futasiAdatok[i].nev+"</td>";
        txt+="<td>"+futasiAdatok[i].Rendszam+"</td>";
        txt+="<td>"+futasiAdatok[i].megtettkilometer+"</td>";
        txt+="<td>"+futasiAdatok[i].kiveteliidopont+"</td>";
        txt+="<td>"+futasiAdatok[i].visszaveteliidopont+"</td>";
        txt+="</tr>";
        
    }
    txt+="</table>";
    txt+="</div>";
    jarmulista.innerHTML=txt;
    
 
}


function javitasiAdatokatkiir()
{
     const jarmulista=document.getElementById('jarmulista');
     jarmulista.innerHTML="";
     
     
    var txt="<div id='nagydoboz'>";
    txt+="<table>";
    txt+="<tr><th>idopont</th><th>nev</th><th>Rendszam</th><th>Gyarto</th><th>Tipus</th><th>Munka</th></tr>";
    for (var i = 0; i <javitasiAdatok.length; i++)
    {
        txt+="<tr>";
        txt+="<td>"+javitasiAdatok[i].idopont+"</td>";
        txt+="<td>"+javitasiAdatok[i].nev+"</td>";
        txt+="<td>"+javitasiAdatok[i].Rendszam+"</td>";
        txt+="<td>"+javitasiAdatok[i].gyartoNeve+"</td>";
        txt+="<td>"+javitasiAdatok[i].nev+"</td>";
        txt+="<td>"+javitasiAdatok[i].munkaNeve+"</td>";
        txt+="</tr>";
        
    }
    txt+="</table>";
    txt+="</div>";
    jarmulista.innerHTML=txt;
    
 
}


//táblába iró metódusok

function hozzaAd()
{
    
   var auto=
        {
            rendszam:$('#rendszam').val(),
            gyartoID:$('#gyartoID').val(),
            tipusID:$('#tipusID').val()
            
          
        
                
        };
     
        
        $.ajax({
           
            type:'POST',
            url:"beir.php",
            data:auto,
            success:function(ujszo)
            {
                alert("sikeres felvitel");
            },
            error:function()
            {
                alert("hibaaz uj adat felvitelekor");
            }
        });
        
 
        
 
}


function FutasthozzaAd()
{

    
    
   var autoFutas=
        {
            autoID:$('#autoID').val(),
            szemelyID:$('#szemelyID').val(),
            megtettKM:$('#megtettKM').val(),
            kiviteliIdopont:$('#kiviteliIdopont').val(),
            beviteliIdopnt:$('#beviteliIdopnt').val()
            
          
        
                
        };
   
        
        $.ajax({
           
            type:'POST',
            url:"futastBeir.php",
            data:autoFutas,
            success:function(ujszo)
            {
                alert("sikeres felvitel");
            },
            error:function()
            {
                alert("hibaaz uj adat felvitelekor");
            }
        });
     
        
 
}


function javitasHozzaAd()
{
    console.log("jo");
    
    
   var autoJavitas=
        {
            autoID:$('#autoID').val(),
            szemelyID:$('#szemelyID').val(),
            javitasiIdopont:$('#javitasiIdopont').val(),
            munkaID:$('#munkaID').val()
        };

    
    console.log(autoJavitas.autoID);
    
        $.ajax({
           
            type:'POST',
            url:"javitasBeir.php",
            data:autoJavitas,
            success:function(ujszo)
            {
                alert("sikeres felvitel");
            },
            error:function()
            {
                alert("hibaaz uj adat felvitelekor");
            }
        });
     
        
 
}





