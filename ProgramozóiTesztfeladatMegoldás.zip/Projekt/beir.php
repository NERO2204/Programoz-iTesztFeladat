<?php

require './MySqlDB.php';
$mySql=new MySqlDB();
extract($_POST);
$rendszam=$_POST["rendszam"];
$gyarto=$_POST["gyartoID"];
$tipus=$_POST["tipusID"];
$mySql->ujRekord("auto", "(Rendszam,gyarto,tipus)","('$rendszam','$gyarto','$tipus')");
echo json_encode($_POST);


