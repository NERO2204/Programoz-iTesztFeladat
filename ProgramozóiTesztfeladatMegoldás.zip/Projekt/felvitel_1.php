<!DOCTYPE html>
<html lang="en">
<head>
  <title>Programozói tesztfeladat</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <script src="feldolgoz2.js" type="text/javascript"></script>
  <link href="style.css" rel="stylesheet" type="text/css"/>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand"
         href="#">Programozói Tesztfeladat</a>
   </div>
     <ul class="nav navbar-nav">
      <li class="active">
       <a href="index.php">Főoldal</a>
      </li>
      <li>
       <a href="felvitel_1.php">Uj auto</a>
      </li>
      <li><a href="Futasfelvisz.php">FutasFelvitel</a></li>
      <li><a href="javitasFelvitel.php">JavitasFelvitel</a></li>
    </ul>
    </div>
</nav>
  <div class="container">

  <h2>Auto felvitel</h2>
  <form class="form-horizontal" >
    <div class="form-group">
      <label class="control-label col-sm-2" for="email">Rendszam</label>
       <div class="col-sm-10">
       
          
         <input type="text" class="form-control" id="rendszam" placeholder="Rendszam">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Gyarto:</label>
      <div class="col-sm-10">          
          <?php
          include './urlapokatTolt.php';
          gyartoIDkatVisszaad();
          ?>
      </div>
    </div>
      <div class="form-group">
      <label class="control-label col-sm-2" for="pwd">Tipus</label>
      <div class="col-sm-10">          
          <?php
                    tipusIDkatVisszaad();
          ?>
      </div>
    </div>
    <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
          <button type="button" onclick="hozzaAd()" class="btn btn-default">elkuld</button>
      </div>
    </div>
  </form>
  </div>
  </form>
</div>
 </body>
</html>
