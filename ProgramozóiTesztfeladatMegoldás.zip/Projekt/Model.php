<?php


require_once './MySqlDB.php';

$ab = new MySqlDB();

$autok = array();
$eredmeny = $ab->autokatLekerdezTipusssal();

if ($eredmeny->num_rows > 0) {
    while($sor = $eredmeny->fetch_assoc()) {
        $autok[] = $sor;
    }
    echo json_encode($autok);
}
else {
    echo "Nincs adat.";
}



