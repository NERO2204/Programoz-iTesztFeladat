<?php
require_once './MySqlDB.php';
$ab = new MySqlDB();
$autokJavitasa = array();
$javitasiAdatok = $ab->javitasiAdatokatLekerdez();
if ($javitasiAdatok->num_rows > 0) {
    while($sor = $javitasiAdatok->fetch_assoc()) {
        $autokJavitasa[] = $sor;
    }
    echo json_encode($autokJavitasa);
}
else {
    echo "Nincs adat.";
}
