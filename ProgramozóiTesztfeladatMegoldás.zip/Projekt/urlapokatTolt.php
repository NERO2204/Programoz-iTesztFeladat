<?php

define('DB_SERVER','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('DB_NAME','autok');
function autoIdkatVisszaadas()
{

$link=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_NAME);
if ($link===false)
{
    die("Error could not connect ". mysqli_error());
    
}

$sql="SELECT * FROM auto";
echo "<select id='autoID'>";
if ($result= mysqli_query($link, $sql))
{
    if (mysqli_num_rows($result)>0)
    {
        while ($row= mysqli_fetch_array($result))
        {
            $dbselected=$row['id'];
            
            
            echo "<option >".$dbselected."</option>";
            
        }
    }
}
echo "</select>";
}







function szemelyIDkatVisszaad()
{

$link=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_NAME);
if ($link===false)
{
    die("Error could not connect ". mysqli_error());
    
}
$sql="SELECT * FROM szemely";
echo "<select id='szemelyID'>";
if ($result= mysqli_query($link, $sql))
{
    if (mysqli_num_rows($result)>0)
    {
        while ($row= mysqli_fetch_array($result))
        {
            $dbselected=$row['id'];
            echo "<option >".$dbselected."</option>";
            
        }
    }
}
echo "</select>";
}




function munkaIDkatVisszaad()
{

$link=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_NAME);
if ($link===false)
{
    die("Error could not connect ". mysqli_error());
    
}
$sql="SELECT * FROM munka";
echo "<select id='munkaID'>";
if ($result= mysqli_query($link, $sql))
{
    if (mysqli_num_rows($result)>0)
    {
        while ($row= mysqli_fetch_array($result))
        {
            $dbselected=$row['id'];
            echo "<option>".$dbselected."</option>";
            ;
           
            
        }
        
    }
}
echo "</select>";

}

function gyartoIDkatVisszaad()
{

$link=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_NAME);
if ($link===false)
{
    die("Error could not connect ". mysqli_error());
    
}
$sql="SELECT * FROM gyarto";
echo "<select id='gyartoID'>";
if ($result= mysqli_query($link, $sql))
{
    if (mysqli_num_rows($result)>0)
    {
        while ($row= mysqli_fetch_array($result))
        {
            $dbselected=$row['id'];
            echo "<option>".$dbselected."</option>";
            ;
           
            
        }
        
    }
}
echo "</select>";

}
function tipusIDkatVisszaad()
{

$link=mysqli_connect(DB_SERVER,DB_USERNAME,DB_PASSWORD,DB_NAME);
if ($link===false)
{
    die("Error could not connect ". mysqli_error());
    
}
$sql="SELECT * FROM tipus";
echo "<select id='tipusID'>";
if ($result= mysqli_query($link, $sql))
{
    if (mysqli_num_rows($result)>0)
    {
        while ($row= mysqli_fetch_array($result))
        {
            $dbselected=$row['id'];
            echo "<option>".$dbselected."</option>";
            ;
           
            
        }
        
    }
}
echo "</select>";

}

