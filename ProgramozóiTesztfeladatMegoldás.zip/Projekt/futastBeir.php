<?php
require './MySqlDB.php';
$mySql=new MySqlDB();
extract($_POST);
$jarmu=$_POST["autoID"];
$szemely=$_POST["szemelyID"];
$megtettKM=$_POST["megtettKM"];
$beviteliIdopont=$_POST["beviteliIdopnt"];
$kivitelIdopont=$_POST['kiviteliIdopont'];
$mySql->ujRekord("futas", "(jarmu,szemely,megtettkilometer,kiveteliidopont,visszaveteliidopont)","('$jarmu','$szemely','$megtettKM','".$kivitelIdopont."','".$beviteliIdopont."')");
echo json_encode($_POST);