<!DOCTYPE html>
<html lang="en">
<head>
  <title>Programozói tesztfeladat</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

  <script src="feldolgoz2.js" type="text/javascript"></script>
  <link href="style.css" rel="stylesheet" type="text/css"/>
</head>
<body>
<header>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="#">Programozói Tesztfeladat</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="active">
      <a href="index.php">Főoldal</a>
      </li>
      <li class="dropdown"><a class="dropdown-toggle" data-toggle="dropdown">Adatok <span class="caret"></span></a>
        <ul class="dropdown-menu">
            <li><button id="autoAdatokatBetolt">Autok adatinak megjelenitése</button></li>
            <li><button id="autoFutasAdatokatMegjelenit">Autok futási adatinak megjelenitése</button></li>
            <li><button id="autoSzervizAdatokatMegjelenit" onclick="javitasiAdatokatLeker()">Autok szerviz adatinak megjelenitése</button></li>
        </ul>
      </li>
      <li><a href="felvitel_1.php">Uj auto</a></li>
      <li><a href="Futasfelvisz.php">FutasFelvitel</a></li>
      <li><a href="javitasFelvitel.php">autoJavitasFelvitel</a></li>
    </ul>
  </div>
</nav>
</header>

    <article>
        <div class="container" id="jarmulista">
        </div>
</article>
<footer>
</footer>
</body>
</html>
