<?php
require './MySqlDB.php';
$mySql=new MySqlDB();
extract($_POST);
$jarmu=$_POST['autoID'];
$szemely=$_POST['szemelyID'];
$javitasiIdopont=$_POST['javitasiIdopont'];
$munkaID=$_POST['munkaID'];
$mySql->ujRekord("szervizeles", "(szemely,auto,idopont,munka)","('".$szemely."','".$jarmu."','".$javitasiIdopont."','".$munkaID."')");
echo json_encode($_POST);
